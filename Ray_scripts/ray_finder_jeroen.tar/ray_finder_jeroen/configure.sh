gcc vincenty.c raypath_point_coords.c -lm -o raypath_point_coords
